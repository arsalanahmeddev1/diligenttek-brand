<section class="trusted-sec pb-100">
  <div class="container">
    <h2 class="hd-lg text-center fw-700 text-black mb-70">
      Technologies We Work With
    </h2>
    <div class="career-brand-slider">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="./assets/images/lang/angular.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/C.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Culture.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Electron.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Flutter.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/go.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/IIM.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Instant-hire.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Java.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Kotlin.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/magento.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/next-js.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/node-js.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Python.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/pytorch.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/react-native.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/Shopify.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/swift.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/top.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/lang/wp.svg" alt="Diligenttek | Career | Trusted by 1600+ of the world's most popular companies">
        </div>
      </div>
    </div>
  </div>
</section>