<header class="d-block d-lg-none">
  <div class="container">
    <div class="row justify-content-between align-items-center">
      <div class="col-5">
        <a href="./"><img src="./assets/images/logo-light.webp" class="md-logo" alt=""></a>
      </div>
      <div class="col-3">
        <ul class="social-links d-flex gap-30 mb-0  align-items-center justify-content-between">
          <li><a href="javascript:;"><i class="fa-brands fa-facebook"></i></a></li>
          <li><a href="javascript:;"><i class="fa-brands fa-instagram"></i></a></li>
          <li><a href="javascript:;"><i class="fa-brands fa-linkedin"></i></a></li>
          <li><a href="javascript:;"><i class="fa-brands fa-youtube"></i></a></li>
        </ul>
      </div>
      <div class="col-3">
        <div class="menu-icon menu-toggle ">
          <i class="fa-solid fa-bars"></i>
        </div>
      </div>
    </div>
  </div>
</header>